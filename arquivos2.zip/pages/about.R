library(shiny)


about_page <- div(
  titlePanel("Sobre"),
  p("This is a about page")
)
