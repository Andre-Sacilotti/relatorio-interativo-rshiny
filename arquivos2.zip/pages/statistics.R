library(shiny)


statistics_page <- div(
  titlePanel("Estatisticas"),
  
  fluidRow(
    column(6, align="center",
           "Teste 1"
    ),
    column(6, align="center", "Teste 1.1")
  ),
  
  fluidRow(
    column(6, align="center", "Teste 2"),
    column(6, align="center", "Teste 2.1")
  )
)
