

## Instalação para gdal

```
sudo apt install libpq-dev
sudo apt install gdal-bin
sudo apt install libodbc1
sudo apt install unixodbc
sudo apt install libgdal-dev
```