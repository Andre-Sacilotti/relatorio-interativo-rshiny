library(shiny)
library(plotly)


predictive_page <- div(
  titlePanel("Modelagem Preditiva"),
  
  fluidRow(
    column(6, align="center",
           "Teste 1"
    ),
    column(6, align="center",
           plotlyOutput("predictive_timeseries", width = "100%"), offset = 1
           )
  )
)
